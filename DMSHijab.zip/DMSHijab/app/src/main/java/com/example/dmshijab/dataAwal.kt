package com.example.dmshijab

class dataAwal {
    var ListProduk = mutableListOf<produk>()
    init {
        ListProduk.add(produk("Hijab A", "H0001", 45000, 20))
        ListProduk.add(produk("Hijab B", "H0002", 55000, 25))
        ListProduk.add(produk("Hijab C", "H0003", 40000, 17))
        ListProduk.add(produk("Hijab D", "H0004", 42000, 17))
        ListProduk.add(produk("Hijab E", "H0005", 45000, 19))
        ListProduk.add(produk("Hijab F", "H0006", 38000, 15))
        ListProduk.add(produk("Hijab G", "H0007", 60000, 22))
        ListProduk.add(produk("Hijab H", "H0008", 57000, 32))
        ListProduk.add(produk("Hijab I", "H0009", 40000, 28))
        ListProduk.add(produk("Hijab J", "H0010", 45000, 10))
    }
    fun getProduk() = ListProduk
    fun addProduk(newProduk: produk){
        ListProduk.add(newProduk)
        getProduk()
    }
}