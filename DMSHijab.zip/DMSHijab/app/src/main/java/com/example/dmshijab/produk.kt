package com.example.dmshijab

class produk (val namaProduk: String, val kode: String, val harga: Int, val jumlah: Int ) {
}