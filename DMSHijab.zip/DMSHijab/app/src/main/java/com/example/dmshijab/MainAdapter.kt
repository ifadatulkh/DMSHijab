package com.example.dmshijab

import android.view.LayoutInflater
import android.widget.TextView
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.LiveData
import androidx.recyclerview.widget.RecyclerView
class MainAdapter(val produk: LiveData<List<produk>>) : RecyclerView.Adapter<mainAdapter.produkViewHolder>() {
    inner class produkViewHolder(items: View) : RecyclerView.ViewHolder(items)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): produkViewHolder{
        val layoutInflater = LayoutInflater.from(parent.context).inflate(R.layout.produk, parent, false)
        return produkViewHolder(layoutInflater)
    }
    override fun getItemCount(): Int {
        return produk.value?.size ?: 0
    }
    override fun onBindViewHolder(holder: produkViewHolder, position: Int) { holder.itemView.apply {
        val tvNamaproduk = findViewById<TextView>(R.id.nama_produk)
        val tvKode = findViewById<TextView>(R.id.kode_produk)
        val tvHarga = findViewById<TextView>(R.id.harga)
        val tvJumlah = findViewById<TextView>(R.id.jumlah)
        tvNamaproduk.text = produk.value?.get(position)?.namaProduk ?: ""
        tvKode.text = produk.value?.get(position)?.kode ?: ""
        tvHarga.text = produk.value?.get(position)?.harga ?: ""
        tvJumlah.text = produk.value?.get(position)?.jumlah ?: ""
    }
    }
}