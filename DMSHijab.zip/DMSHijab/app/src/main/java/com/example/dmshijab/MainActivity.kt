package com.example.dmshijab

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val dataProduk = dataAwal()
        val produkViewModel = produkViewModel(dataProduk)
        val rvMain = findViewById<RecyclerView>(R.id.item_penjualan)
        rvMain.adapter = MainAdapter(produkViewModel.getProduk())
        rvMain.layoutManager = LinearLayoutManager(this)
        val namaproduk = findViewById<EditText>(R.id.nama_produk_penjualan)
        val kode = findViewById<EditText>(R.id.kode_produk_penjualan)
        val harga = findViewById<EditText>(R.id.harga)
        val jumlah = findViewById<EditText>(R.id.jumlah)
        val btnAdd = findViewById<Button>(R.id.button_add)
        val btnTotal = findViewById<Button>(R.id.button_total)
        btnAdd.setOnClickListener {
            val namaproduk = namaproduk.getText().toString()
            val kode = kode.getText().toString()
            val harga = harga.getText().toString()
            val jumlah = jumlah.getText().toString()
            produkViewModel.addProduk(produk(namaproduk, kode, harga, jumlah))
            rvMain.adapter = MainAdapter(produkViewModel.getProduk())
            rvMain.layoutManager = LinearLayoutManager(this)
        }
    }
}