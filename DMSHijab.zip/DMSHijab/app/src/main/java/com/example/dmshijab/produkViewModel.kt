package com.example.dmshijab

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class produkViewModel(val DataProduk: dataAwal):
    ViewModel() {
    var produk = MutableLiveData<List<produk>>()
    fun getProduk(): LiveData<List<produk>>{
        produk.value = DataProduk.getProduk()
        return produk
    }
    fun addProduk(newProduk: produk){
        DataProduk.addProduk(newProduk)
        produk.value = DataProduk.getProduk()
    }
    fun lessProduk(newProduk: produk){

    }
}